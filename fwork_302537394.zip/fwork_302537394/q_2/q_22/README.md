to compile please type from the correct directory:
make all

to run server:
./server

to run client:
./client <sigint(2)> <int as amount>
or
./client <siguser1(10)> <int as amount(1)>
