to compile please type from the correct directory:
make all

to run:
./dir_traversal dir
