to compile please type from the correct directory:
make all

To run a program to stay alive and get its pid run :
./just_run

to check if process exists type:
./check_pid <pid>
